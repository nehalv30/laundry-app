# Laundary-Management-System
## this a basic python application which calculates the the total cost for a laundary. This software is more useful in universities where people have manual system of keeping records. This will send the recepit of the laundary to that particular person since many people tend to loose it.
